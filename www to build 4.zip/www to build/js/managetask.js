function addTask() {

    $.mobile.changePage("addTask.html", {
        transition: "none"
    });
}
